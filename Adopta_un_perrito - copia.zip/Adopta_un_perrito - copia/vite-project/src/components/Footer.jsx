import React from 'react';

const Footer = ({ descripcion }) => {
  return (
    <footer className="footer">
      <p>{descripcion}</p>
    </footer>
  );
};

export default Footer;