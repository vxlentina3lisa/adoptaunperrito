import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './components/Header';
import Footer from './components/Footer';
import MyCard from './components/MyCard';

function App() {
  return (
    <>
      <Header title="Adopta un perrito" />

      <div className="card-container">
        <MyCard
          imagen="https://i.pinimg.com/originals/9c/da/15/9cda153af17ea1a9108e934ff3e67f31.jpg"
          title="Turulín y Turulón"
          descripcion="Hermosos perritoss buscan hogar, (No son fantasmas de verdad) "
          tagText="Perritos Fantasmas"
          tagColor="primary"
        />
        <MyCard
          imagen="https://i.pinimg.com/originals/a1/6c/a2/a16ca2fc12f79a2e678e18a955e01651.jpg"
          title="Diaulo"
          descripcion="Perrito Diablo busca hogar (Calabaza incluida)"
          tagText="Perrito diablo"
          tagColor="warning"
        />
        <MyCard
          imagen="https://i.pinimg.com/originals/4f/f6/c8/4ff6c8a6c5e2db5be04c4ffaa6a68618.jpg"
          title="Calabazaurio"
          descripcion="Un perrito juguetón (y para nada amigable)"
          tagText="Perrito calabaza"
          tagColor="success"
        />
      </div>
      <Footer descripcion="Adorables perritos buscan hogar." />
    </>
  );
}

export default App;
